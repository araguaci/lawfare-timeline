---
layout: post
title: "Cartão corporativo da Presidência: 99% dos R$ 55,5 milhões sob sigilo"
date: 2023-01-01 00:00:00 -0300
description: "Gastos com cartão corporativo da Presidência da República somam R$ 55,5 milhões, com 99% das despesas sem identificação pública de beneficiário, estabelecimento ou finalidade. Padrão P11: opacidade orçamentária como proteção estrutural do gasto."
categories: [governo]
tags:
  - p11
  - cartao-corporativo
  - presidencia
  - sigilo
  - transparencia
  - gastos-publicos
  - opacidade-orcamentaria
author: araguaci
id_corpus: 167
padroes_ativados:
  - P11
corpus_refs:
  - id: 191
    descricao: "T-191 — dossiê P11 orçamentário; cartão corporativo como componente do padrão"
  - id: 177
    descricao: "Viagens sigilosas R$ 405 mi — mesma arquitetura de opacidade"
status_investigativo: confirmado
licenca: "CC0 1.0"
---

## Evento

As despesas com cartão corporativo da Presidência da República totalizaram **R$ 55,5 milhões**, com **99% das transações sem qualquer identificação pública** — sem beneficiário, sem estabelecimento, sem finalidade declarada. O dado é acessível em valor agregado no Portal da Transparência, mas a granularidade necessária para avaliar adequação e legalidade dos gastos permanece classificada.

O padrão persiste entre governos: os mecanismos de opacidade que protegem o cartão corporativo foram construídos ao longo de múltiplas administrações e não foram reformados por nenhuma delas.

## Padrão P11 — opacidade como proteção estrutural

A distinção analítica relevante: **a opacidade não é falha, é design**. Se 99% das despesas fossem identificáveis, qualquer gasto irregular produziria pressão pública imediata. A classificação sistemática como sigiloso funciona como proteção estrutural do padrão — não protege um gasto específico, protege a categoria inteira de avaliação.

O cartão corporativo da Presidência é o componente mais direto do Padrão P11 neste dossiê: é gasto do núcleo do Executivo, com valor relevante, integralmente opaco, e sem qualquer mecanismo efetivo de accountability.

## Cadeia lógica

`R$ 55,5 mi em gastos` → `99% sem identificação` → `Portal exibe valor total, não composição` → `Impossível avaliar adequação por transação` → `Padrão estável entre governos`

## Conexão com série histórica

Este evento integra o cluster documentado no dossiê T-191 junto com:
- Viagens sigilosas (R$ 405 mi, 2024)
- Frota TST (R$ 10,39 mi, 2025)
- Orçamento secreto (R$ 4,2 bi suspenso pelo STF)
- Diárias Câmara (+78%, 2025)
- Custeio total (R$ 32,4 bi no 1º semestre 2025)

## Fontes

- Portal da Transparência do Governo Federal — Cartão de Pagamento
- Respostas a pedidos LAI sobre cartão corporativo da Presidência
- Dossiê T-191 (lawfare-timeline)
