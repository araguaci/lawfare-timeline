---
layout: post
title: "Câmara dos Deputados: diárias disparam 78% em 2025 — reajuste sem justificativa proporcional"
date: 2024-04-01 00:00:00 -0300
description: "As diárias pagas a deputados e servidores da Câmara dos Deputados registraram crescimento de 78% em 2025 em relação ao exercício anterior, sem justificativa de expansão de escopo, inflação correspondente ou aumento documentado de atividade parlamentar."
categories: [governo]
tags:
  - p11
  - camara-dos-deputados
  - diarias
  - gastos-publicos
  - transparencia
  - congresso
  - penduricalhos
author: araguaci
id_corpus: 176
padroes_ativados:
  - P11
corpus_refs:
  - id: 191
    descricao: "T-191 — dossiê P11 orçamentário; diárias da Câmara como componente do padrão"
  - id: 178
    descricao: "Custeio total R$ 32,4 bi — Congresso como aprovador e beneficiário do padrão"
  - id: 177
    descricao: "Viagens sigilosas R$ 405 mi — padrão análogo de gasto sem granularidade"
status_investigativo: confirmado
licenca: "CC0 1.0"
---

## Evento

As despesas com diárias pagas a deputados federais e servidores da Câmara dos Deputados registraram crescimento de **78% em 2025** em relação ao exercício anterior. O aumento nominal não foi acompanhado de explicação institucional que justifique variação de tal magnitude por inflação, expansão de atividade ou alteração de escopo de trabalho parlamentar.

## O paradoxo estrutural do P11 no Legislativo

O Congresso Nacional é simultaneamente o aprovador do orçamento que contém o padrão P11 e seu principal beneficiário via diárias, passagens, verbas indenizatórias e emendas parlamentares. Esse paradoxo é a razão estrutural pela qual o padrão é estável: o único ator com poder de voto para cortar o custeio federal não tem incentivo para fazê-lo, porque parte relevante desse custeio é seu próprio benefício.

O crescimento de 78% nas diárias da Câmara não é o maior componente do custeio federal em valor absoluto — mas é analiticamente o mais revelador: documenta que o Legislativo aplica a si mesmo o oposto da contenção que vota para o Executivo.

## Assimetria de escrutínio

Diárias do Legislativo recebem menos escrutínio do que gastos equivalentes do Executivo, porque o Congresso não está sujeito às mesmas obrigações de publicidade ativa e porque o TCU tem menor autonomia para questionar despesas do Legislativo do que do Executivo. O resultado é documentado: crescimentos de 78% passam sem investigação jornalística equivalente ao que receberia uma despesa de mesmo porte no Executivo.

## Cadeia lógica

`Câmara aprova orçamento` → `Câmara é beneficiária do próprio orçamento` → `Diárias crescem 78%` → `Sem pressão de corte externo` → `Congresso sem incentivo de contenção`

## Fontes

- Portal da Transparência da Câmara dos Deputados
- Relatório de Execução Orçamentária da Câmara
- Dossiê T-191 (lawfare-timeline)
