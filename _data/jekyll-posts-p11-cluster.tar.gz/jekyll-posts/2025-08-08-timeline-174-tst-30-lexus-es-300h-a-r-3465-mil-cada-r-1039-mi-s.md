---
layout: post
title: "TST: 30 Lexus ES 300H a R$ 346,5 mil cada (R$ 10,39 mi) + sala VIP aeroporto"
date: 2025-08-08 00:00:00 -0300
description: "O Tribunal Superior do Trabalho adquiriu 30 veículos Lexus ES 300H a R$ 346,5 mil cada, totalizando R$ 10,39 milhões, além de sala VIP em aeroporto. Licitação regular — o problema é a prioridade alocativa, não a ilegalidade formal."
categories: [governo]
tags:
  - p11
  - tst
  - judiciario
  - frota
  - lexus
  - gastos-publicos
  - extravagancia
  - penduricalhos
author: araguaci
id_corpus: 174
padroes_ativados:
  - P11
corpus_refs:
  - id: 191
    descricao: "T-191 — dossiê P11 orçamentário; TST como instância judicial do padrão"
  - id: 175
    descricao: "Gilmarpalooza — padrão análogo de extravagância no Judiciário"
  - id: 182
    descricao: "Acumulação funções Moraes/8J — P11 e P03 coexistem no Judiciário"
status_investigativo: confirmado
licenca: "CC0 1.0"
---

## Evento

O Tribunal Superior do Trabalho (TST) adquiriu **30 veículos Lexus ES 300H** ao preço unitário de **R$ 346,5 mil**, totalizando **R$ 10,39 milhões**. O tribunal adquiriu também sala VIP em aeroporto para uso de ministros e autoridades.

A aquisição foi realizada via licitação regular, dentro dos parâmetros formais do processo de compras públicas. Não há irregularidade processual documentada.

## Por que é P11

A distinção analítica central do Padrão P11: **a legalidade formal do ato não é a questão**. Um tribunal pode licitar regularmente uma frota de veículos de luxo sem cometer nenhum ato ilegal isolado. O problema é de **prioridade alocativa estrutural**: o mesmo sistema judicial que demora décadas para julgar ações trabalhistas ordinárias utiliza recursos públicos para adquirir a mais cara configuração disponível de veículo executivo para seus membros.

O episódio captura atenção midiática desproporcional ao valor (R$ 10,39 mi) em relação a componentes maiores do mesmo padrão que permanecem opacos (viagens sigilosas: R$ 405 mi; custeio total: R$ 32,4 bi no 1º semestre 2025). A assimetria de visibilidade é ela própria parte do mecanismo: escândalos pontuais de alto impacto visual substituem a cobertura do padrão estrutural.

## Judiciário como vetor P11

O Judiciário não está sujeito às mesmas regras de austeridade que impõe ao Executivo via decisões sobre orçamento e gastos. A frota de luxo do TST é a versão mais visível de um padrão documentado em outros componentes: gastos internacionais do STF (Gilmarpalooza, ID 175), manutenção de sigilo de viagens (STF e Senado, ID 177), acumulação de funções sem contenção externa (ID 182).

## Cadeia lógica

`TST licita 30 × Lexus ES 300H` → `Licitação regular — nenhum ato ilícito isolado` → `R$ 10,39 mi em frota de luxo + sala VIP` → `Padrão P11: prioridade alocativa sem accountability` → `Judiciário não sujeito às mesmas regras de contenção que impõe ao Executivo`

## Fontes

- Diário da Justiça do Trabalho — edital e resultado de licitação TST
- Portal da Transparência — contratos TST
- Dossiê T-191 (lawfare-timeline)
