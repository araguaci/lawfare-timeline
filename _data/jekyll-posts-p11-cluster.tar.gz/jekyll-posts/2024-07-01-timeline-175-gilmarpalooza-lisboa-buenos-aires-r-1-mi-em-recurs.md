---
layout: post
title: "Gilmarpalooza (Lisboa + Buenos Aires): R$ 1 mi+ em recursos do Legislativo"
date: 2024-07-01 00:00:00 -0300
description: "Despesas com viagens internacionais de Lisboa e Buenos Aires associadas ao ministro Gilmar Mendes, custeadas por recursos do Legislativo, somaram mais de R$ 1 milhão. Instância de P11 × P09 no Judiciário: gastos de representação sem prestação de contas detalhada."
categories: [governo]
tags:
  - p11
  - p09
  - gilmar-mendes
  - stf
  - judiciario
  - viagens
  - gastos-publicos
  - lisboa
  - buenos-aires
  - penduricalhos
author: araguaci
id_corpus: 175
padroes_ativados:
  - P11
  - P09
corpus_refs:
  - id: 109
    descricao: "Gilmar Mendes — dossiê temático; Gilmarpalooza como instância de P11 no Judiciário"
  - id: 191
    descricao: "T-191 — dossiê P11 orçamentário; Judiciário como vetor do padrão"
  - id: 174
    descricao: "TST Lexus — padrão análogo de gasto judicial de representação"
  - id: 177
    descricao: "Viagens sigilosas R$ 405 mi — Judiciário manteve sigilo no mesmo cluster"
status_investigativo: confirmado
licenca: "CC0 1.0"
---

## Evento

Despesas associadas a viagens internacionais do ministro do Supremo Tribunal Federal **Gilmar Mendes** a **Lisboa** e **Buenos Aires** — custeadas por recursos do Legislativo — somaram mais de **R$ 1 milhão**. As despesas foram identificadas via Portal da Transparência e investigação jornalística.

O episódio foi denominado "Gilmarpalooza" pela imprensa em referência à combinação de eventos de alto custo em cidades com significado político e cultural relevante para o ministro.

## P11 × P09 no Judiciário

O caso documenta a interseção entre dois padrões do corpus:

**P11 (Extração Estrutural):** recursos públicos utilizados para viagens internacionais de membro do Judiciário sem prestação de contas de granularidade equivalente ao que seria exigido de gestores do Executivo para despesas de mesmo valor.

**P09 (Nexo Político-Regulatório):** o ministro do STF com maior histórico documentado de atuação em casos de interesse de grupos políticos e econômicos organizados utiliza recursos do Legislativo — que ele indiretamente supervisiona via controle de constitucionalidade — para financiar agenda internacional.

## O Judiciário como zona de menor accountability

O Judiciário não está formalmente sujeito ao mesmo sistema de controle de despesas que o Executivo. Compras do TST (Lexus), viagens do STF (mantidas sigilosas), gastos internacionais de ministros via verbas do Legislativo — todos são processados com menor escrutínio do TCU e menor exposição pública do que despesas equivalentes no Executivo.

## Cadeia lógica

`Ministro STF` → `Viagens Lisboa + Buenos Aires` → `Custeio via recursos do Legislativo` → `Mais de R$ 1 mi` → `Sem prestação de contas detalhada` → `P11: gasto real + P09: nexo político do beneficiário`

## Fontes

- Portal da Transparência do Governo Federal
- Reportagens investigativas — O Globo, UOL, Metrópoles
- Dossiê temático T-109 (Gilmar Mendes — lawfare-timeline)
- Dossiê T-191 (lawfare-timeline)
