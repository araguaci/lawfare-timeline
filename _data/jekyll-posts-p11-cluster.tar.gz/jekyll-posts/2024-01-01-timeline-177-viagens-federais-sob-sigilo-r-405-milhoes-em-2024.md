---
layout: post
title: "Viagens federais sob sigilo: R$ 405 milhões em 2024 — STF e Senado mantidos"
date: 2024-01-01 00:00:00 -0300
description: "Despesas com viagens do funcionalismo federal somam R$ 405 milhões em 2024, com 99% dos dados classificados como sigilosos. STF e Senado obtiveram manutenção do sigilo via recursos próprios, impedindo identificação individual dos beneficiários."
categories: [governo]
tags:
  - p11
  - p03
  - viagens
  - sigilo
  - transparencia
  - stf
  - senado
  - gastos-publicos
  - opacidade-orcamentaria
author: araguaci
id_corpus: 177
padroes_ativados:
  - P11
  - P03
corpus_refs:
  - id: 191
    descricao: "T-191 — dossiê P11 orçamentário; este evento integra o cluster de gastos opacos"
  - id: 174
    descricao: "TST Lexus — padrão análogo de gasto judicial sem accountability"
  - id: 182
    descricao: "Acumulação de funções Moraes/8J — STF como beneficiário e bloqueador de escrutínio"
status_investigativo: confirmado
licenca: "CC0 1.0"
---

## Evento

As despesas com viagens de servidores e autoridades do governo federal totalizaram **R$ 405 milhões em 2024**. Segundo dados do Portal da Transparência, **99% desses gastos estão classificados como sigilosos** — os portais exibem o valor agregado, mas não identificam beneficiários individuais, destinos ou justificativas por viagem.

O Supremo Tribunal Federal e o Senado Federal, ao serem questionados sobre a publicação detalhada, obtiveram manutenção do sigilo mediante recursos institucionais próprios.

## Mecanismo de opacidade

O Estado brasileiro utiliza a classificação de sigilo de forma assimétrica: informações sobre investigações criminais são divulgadas seletivamente, enquanto informações sobre gastos com o próprio aparato permanecem protegidas. Trata-se da mesma arquitetura de opacidade documentada em contextos de segurança — sigilo como política de Estado aplicada tanto a operações quanto a despesas administrativas.

O dado de R$ 405 milhões é auditável em valor agregado mas não em composição. A ausência de granularidade impede qualquer avaliação de razoabilidade por viagem, destino ou função exercida.

## Padrão P11 × P03

A interseção entre P11 (extração orçamentária estrutural) e P03 (chokepoint institucional) é documentada neste caso: o STF, que deveria supervisionar o princípio constitucional da publicidade da administração pública, utiliza seu poder institucional para proteger seus próprios gastos do escrutínio externo. O órgão supervisiona e é supervisionado pelo mesmo conjunto de regras que aplica de forma seletiva.

## Cadeia lógica

`Gasto de R$ 405 mi com viagens` → `99% classificado como sigiloso` → `STF e Senado mantêm sigilo via recursos` → `Portal exibe valor sem composição` → `Accountability impossibilitado por design`

## Fontes

- Portal da Transparência do Governo Federal — Viagens a Serviço
- Respostas institucionais STF e Senado Federal a pedidos de LAI
- Dossiê T-191 (lawfare-timeline)
