---
layout: post
title: "Novo orçamento secreto: STF suspende repasses de R$ 4,2 bilhões em emendas parlamentares"
date: 2025-01-01 00:00:00 -0300
description: "O Supremo Tribunal Federal suspendeu repasses de R$ 4,2 bilhões em emendas parlamentares por ausência de critérios públicos de distribuição — configurando um segundo ciclo do mecanismo chamado de 'orçamento secreto', desta vez em modalidade distinta das emendas de relator."
categories: [escandalos]
tags:
  - p11
  - p03
  - orcamento-secreto
  - emendas-parlamentares
  - stf
  - congresso
  - transparencia
  - controle-orcamentario
author: araguaci
id_corpus: "novo-orcamento-secreto"
padroes_ativados:
  - P11
  - P03
corpus_refs:
  - id: 191
    descricao: "T-191 — dossiê P11 orçamentário; orçamento secreto como interseção P11 × P03"
  - id: 178
    descricao: "Custeio R$ 32,4 bi — mesmo ecossistema orçamentário"
  - id: 182
    descricao: "Acumulação funções Moraes/8J — STF como árbitro de recursos orçamentários que beneficiam os mesmos congressistas"
status_investigativo: confirmado
licenca: "CC0 1.0"
---

## Evento

O Supremo Tribunal Federal suspendeu repasses de **R$ 4,2 bilhões** em emendas parlamentares, por ausência de critérios públicos e transparentes de distribuição. A decisão configurou um segundo ciclo do fenômeno denominado "orçamento secreto" — desta vez em modalidade diferente das emendas de relator suspensas anteriormente, mas com a mesma característica estrutural: recursos públicos distribuídos por critérios não publicizados, em benefício de interesses parlamentares específicos, sem rastreabilidade pública.

## P11 × P03 — interseção documentada

Este evento é a instância mais precisa da interseção entre P11 e P03 em todo o dossiê T-191:

**P11:** os R$ 4,2 bilhões em emendas representam transferência de recursos públicos a critérios opacos, operando como mecanismo de captura de votos e financiamento de base política parlamentar.

**P03:** o STF atua como árbitro que decide quais critérios de distribuição são constitucionais — ou seja, o tribunal de cúpula define as regras do jogo orçamentário que afeta diretamente os parlamentares que votam sobre o orçamento do próprio STF, composição do tribunal e estrutura do Judiciário.

A circularidade é o mecanismo: o STF supervisiona o Congresso; o Congresso aprova o orçamento do STF; o STF define se os mecanismos orçamentários que beneficiam o Congresso são constitucionais.

## Orçamento secreto — persistência do padrão

O primeiro ciclo do "orçamento secreto" (emendas de relator, 2019–2022) foi suspenso pelo STF após decisão do ministro Rosa Weber em 2022. O presente episódio documenta que o padrão não foi eliminado — migrou para outra modalidade de emendas com critérios igualmente opacos. A adaptabilidade do mecanismo após intervenção judicial é evidência adicional de sua natureza estrutural.

## Cadeia lógica

`Emendas parlamentares sem critérios públicos` → `R$ 4,2 bi distribuídos de forma opaca` → `STF suspende os repasses` → `Congresso que aprova orçamento STF é o mesmo beneficiário das emendas` → `STF arbitra regras que afetam diretamente seus próprios financiadores institucionais` → `P11 × P03: extração + chokepoint`

## Fontes

- Decisão do STF suspendendo emendas parlamentares — jan/2025
- Portal da Transparência — execução orçamentária de emendas
- Reportagens investigativas — Folha de S.Paulo, O Globo, Estadão
- Dossiê T-191 (lawfare-timeline)
