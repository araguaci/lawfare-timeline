---
layout: post
title: "Olimpíadas de Paris: R$ 235 mil em viagem de 4 dias — comitiva governamental"
date: 2024-07-26 00:00:00 -0300
description: "Viagem da comitiva governamental brasileira às Olimpíadas de Paris em julho de 2024 somou R$ 235 mil em 4 dias, representando custo per capita de representação sem parâmetro de austeridade equivalente ao exigido de outros entes públicos."
categories: [governo]
tags:
  - p11
  - olimpiadas
  - paris
  - viagens
  - gastos-publicos
  - penduricalhos
  - representacao
author: araguaci
id_corpus: 170
padroes_ativados:
  - P11
corpus_refs:
  - id: 191
    descricao: "T-191 — dossiê P11 orçamentário; Olimpíadas como instância de prioridade alocativa"
  - id: 172
    descricao: "Desfile Janja em Paris R$ 344 mil — evento correlato de representação exterior"
  - id: 175
    descricao: "Gilmarpalooza R$ 1 mi+ — padrão análogo de custo de representação internacional"
status_investigativo: confirmado
licenca: "CC0 1.0"
---

## Evento

A comitiva governamental brasileira às **Olimpíadas de Paris (julho de 2024)** gerou despesas de **R$ 235 mil em 4 dias**. O dado foi obtido via Portal da Transparência e pedidos de Lei de Acesso à Informação.

## Contexto analítico

Em valor absoluto, R$ 235 mil é um dos menores componentes do cluster P11 documentado no dossiê T-191. O episódio é incluído na série não por magnitude, mas pelo que revela sobre **prioridade alocativa e ausência de parâmetro de austeridade**.

O Estado brasileiro exige que municípios e estados comprovem contrapartidas, eficiência e racionalidade de gasto para acessar transferências federais. O mesmo Estado não aplica critério equivalente às despesas de representação de suas próprias autoridades em eventos internacionais.

A Olimpíada de Paris concentrou dois eventos de representação governamental com custo documentado: a comitiva (R$ 235 mil) e o desfile de Janja em evento de moda custeado pela Apex (R$ 344 mil via recursos públicos). Lidos em conjunto, documentam a mesma lógica: recursos públicos financiam eventos de agenda pessoal/política de autoridades sem escrutínio equivalente ao aplicado a gastos de menor valor em outros entes.

## Cadeia lógica

`Olimpíadas de Paris` → `Comitiva governamental custeada com recursos públicos` → `R$ 235 mil em 4 dias` → `Sem parâmetro de austeridade equivalente ao exigido de outros entes` → `Padrão P11: prioridade alocativa sem accountability`

## Fontes

- Portal da Transparência do Governo Federal — Viagens a Serviço
- Pedidos LAI sobre comitiva brasileira às Olimpíadas de Paris 2024
- Dossiê T-191 (lawfare-timeline)
