---
layout: post
title: "Custeio administrativo federal: R$ 32,4 bilhões no 1º semestre 2025"
date: 2025-01-01 00:00:00 -0300
description: "Despesas de custeio do aparato federal atingem R$ 32,4 bilhões no primeiro semestre de 2025 — crescimento acima da inflação sem mecanismo efetivo de contenção. Padrão P11: extração macroeconômica estrutural via orçamento público."
categories: [governo]
tags:
  - p11
  - custeio
  - orcamento-federal
  - transparencia
  - extravagancia
  - gastos-publicos
  - tcu
  - cgu
author: araguaci
id_corpus: 178
padroes_ativados:
  - P11
  - P03
  - P09
corpus_refs:
  - id: 191
    descricao: "T-191 — dossiê temático consolidando o padrão P11 orçamentário"
  - id: 128
    descricao: "Brasil Sangra — extração macroeconômica estrutural"
  - id: 122
    descricao: "República Capturada — tese central de sistema de extração"
status_investigativo: confirmado
licenca: "CC0 1.0"
---

## Evento

No primeiro semestre de 2025, as despesas de custeio administrativo do governo federal atingiram **R$ 32,4 bilhões** — montante que, projetado para o ano inteiro, ultrapassa o orçamento de diversos ministérios combinados.

O dado engloba pessoal ativo, benefícios, diárias, passagens, serviços de manutenção e contratos de apoio administrativo do Executivo federal, excluídas transferências obrigatórias e investimentos.

## Contexto estrutural

O crescimento do custeio federal é contínuo e supera a inflação há múltiplos exercícios consecutivos. O Tribunal de Contas da União (TCU) e a Controladoria-Geral da União (CGU) documentam a trajetória ascendente em relatórios periódicos, sem que isso produza mecanismo de corte efetivo.

A razão estrutural é documentada no corpus: o único ator com poder de redução orçamentária (Congresso Nacional) é simultaneamente o maior beneficiário do padrão, via diárias, passagens e estrutura de gabinetes — cujas despesas cresceram 78% em 2025 apenas na Câmara dos Deputados (ver ID 176).

## Padrão P11 — extração formal

Este evento é instância direta do **Padrão P11 (Extração Macroeconômica Estrutural)**: a transferência sistemática de recursos públicos ocorre via mecanismos formalmente legais — nenhum ato individual é ilícito, o problema está na arquitetura. A aceitabilidade formal é o mecanismo de proteção: nenhum gestor pode ser responsabilizado pelo conjunto enquanto cada ato é orçamentariamente autorizado.

O custeio de R$ 32,4 bilhões se insere na série histórica documentada no dossiê **T-191**, que consolida os seguintes componentes do padrão P11 no ciclo 2023–2025:

- Viagens federais sob sigilo: R$ 405 milhões em 2024 (99% opacos)
- Cartão corporativo da Presidência: R$ 55,5 milhões (99% sem identificação)
- Frota TST: 30 × Lexus ES 300H — R$ 10,39 milhões
- Diárias Câmara dos Deputados: +78% em 2025
- Rombo das estatais federais: R$ 4,16 bilhões (1º tri 2026)
- Orçamento secreto: STF suspendeu R$ 4,2 bilhões em emendas parlamentares

## Cadeia lógica

`Dotação aprovada pelo Congresso` → `Gestores sem incentivo de corte` → `Expansão acima da inflação` → `Sigilo protege execução` → `TCU/CGU identificam sem poder de corte` → `Congresso não vota redução` → `Déficit estrutural permanente`

## Fontes

- Portal da Transparência do Governo Federal
- Relatórios TCU — Acompanhamento de Despesas de Pessoal e Custeio
- CGU — Relatórios de Execução Orçamentária
- Dossiê T-191 (lawfare-timeline)
