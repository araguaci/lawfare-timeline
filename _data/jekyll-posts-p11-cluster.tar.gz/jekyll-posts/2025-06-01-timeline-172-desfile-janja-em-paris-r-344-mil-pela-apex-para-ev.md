---
layout: post
title: "Desfile Janja em Paris: R$ 344 mil pela Apex para evento com Brigitte Macron"
date: 2025-06-01 00:00:00 -0300
description: "A Agência Brasileira de Promoção de Exportações e Investimentos (Apex-Brasil) custeou participação de Rosângela Lula Silva em evento de moda em Paris com verba de R$ 344 mil, enquadrando o gasto como ação de promoção do Brasil no exterior."
categories: [governo]
tags:
  - p11
  - apex
  - paris
  - janja
  - gastos-publicos
  - representacao
  - penduricalhos
author: araguaci
id_corpus: 172
padroes_ativados:
  - P11
corpus_refs:
  - id: 191
    descricao: "T-191 — dossiê P11 orçamentário; Apex/Paris como instância de prioridade alocativa"
  - id: 170
    descricao: "Olimpíadas de Paris R$ 235 mil — eventos correlatos de representação exterior"
  - id: 175
    descricao: "Gilmarpalooza R$ 1 mi+ — padrão de custo de agenda internacional sem parâmetro"
status_investigativo: confirmado
licenca: "CC0 1.0"
---

## Evento

A **Apex-Brasil** (Agência Brasileira de Promoção de Exportações e Investimentos) custeou a participação de **Rosângela Lula Silva** em evento de moda em Paris, com presença de **Brigitte Macron**, ao custo de **R$ 344 mil**. O gasto foi enquadrado institucionalmente como ação de promoção do Brasil no exterior.

## Análise P11 — prioridade alocativa e enquadramento institucional

O caso documenta a lógica de enquadramento que protege gastos de agenda pessoal/política de autoridades sob a categoria de "promoção institucional". A Apex-Brasil é uma entidade de serviço público cuja missão formal é promoção de exportações e atração de investimentos. O custeio de participação em desfile de moda para a cônjuge do presidente da República é enquadrado como ação de missão — o que permite a utilização de recursos públicos sem que nenhum ato isolado seja formalmente ilegal.

Este é o mecanismo P11 na sua versão mais limpa: **enquadramento institucional como proteção do gasto**. A despesa não precisa ser irregular para ser problemática; basta ser inadequada em relação à missão da entidade e ao princípio de eficiência do gasto público.

O episódio ocorreu na mesma cidade (Paris) e no mesmo período (2024–2025) que a comitiva olímpica (R$ 235 mil, ID 170), documentando uma sobreposição de gastos de representação internacional sem parâmetro de austeridade.

## Cadeia lógica

`Apex-Brasil (entidade pública)` → `Financia participação da cônjuge do presidente em desfile de moda` → `R$ 344 mil` → `Enquadrado como "promoção do Brasil no exterior"` → `Enquadramento institucional como proteção do gasto — P11`

## Fontes

- Portal da Transparência — contratos e despesas Apex-Brasil
- Pedidos LAI sobre participação em eventos internacionais
- Reportagens investigativas — Folha de S.Paulo, O Globo
- Dossiê T-191 (lawfare-timeline)
